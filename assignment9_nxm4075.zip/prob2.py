#opening file training data for reading

file = open("training_data.txt", "r")
dataline = []

#appeding file for reading

for line in file:
    dataline.append(line.split())

#initializing count variables

O = 0
B = 0
GTrueB = 0
TrueGTrueO = 0
FTrueGFalseO = 0
TrueGFalseO = 0
FFalseGTrueO = 0
FalseGTrueO = 0
FFalseGFalseO = 0
FalseGFalseO = 0
TrueB = 0
GFalseB = 0
FTrueGTrueO = 0

#reading the file and incremeenting the count variables

for i in range(0, len(dataline)):
    if int(dataline[i][0]) == 1:
        B += 1
    if int(dataline[i][2]) == 1:
        O += 1
    if int(dataline[i][0]) == 1 and int(dataline[i][1]) == 1:
        GTrueB += 1
    if (int(dataline[i][0]) == 1) == 1:
        TrueB += 1
    if int(dataline[i][0]) == 0 and int(dataline[i][1]) == 1:
        GFalseB += 1
    
    if int(dataline[i][1]) == 1 and int(dataline[i][2]) == 0:
        TrueGFalseO += 1
    if int(dataline[i][1]) == 0 and int(dataline[i][2]) == 1 and int(dataline[i][3]) == 1:
        FFalseGTrueO += 1
    if int(dataline[i][1]) == 0 and int(dataline[i][2]) == 1:
        FalseGTrueO += 1
    if int(dataline[i][1]) == 0 and int(dataline[i][2]) == 0 and int(dataline[i][3]) == 1:
        FFalseGFalseO += 1
    if int(dataline[i][1]) == 0 and int(dataline[i][2]) == 0:
        FalseGFalseO += 1

    if int(dataline[i][1]) == 1 and int(dataline[i][2]) == 1 and int(dataline[i][3]) == 1:
        FTrueGTrueO += 1
    if int(dataline[i][1]) == 1 and int(dataline[i][2]) == 1:
        TrueGTrueO += 1
    if int(dataline[i][1]) == 1 and int(dataline[i][2]) == 0 and int(dataline[i][3]) == 1:
        FTrueGFalseO += 1
    


#print statement for data
print ("P(O)= %f" % (O/365.0))
print ("P(B)= %f" % (B/365.0))
print ("P(G=T|B=T) = %f" % (GTrueB/float(TrueB)))
print ("P(G=T|B=F) = %f" % (GFalseB/float(365 - TrueB)))
print ("P(F=T|G=T,O=T) = %f"% (FTrueGTrueO/float(TrueGTrueO)))
print ("P(F=T|G=T,O=F) = %f"% (FTrueGFalseO/float(TrueGFalseO)))
print ("P(F=T|G=F,O=T) = %f"% (FFalseGTrueO/float(FalseGTrueO)))
print ("P(F=T|G=F,O=F) = %f"%(FFalseGFalseO/float(FalseGFalseO)))

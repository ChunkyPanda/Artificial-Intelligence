Neil Malhotra
1001084075

I have used pyhton to code both problem 2 and problem 3. 

Instructions to run code on omega:

For problem 2

python prob2.py

For problem 3 

python bnet.py [query1] [query2]..... given [obs1][obs2]


for example 

python bnet Jt Af given Bt Ef



Neil Malhotra

1001084075

I used python programming language for this project.

Thee project was used with the help of maxconnect4.py and MaxConnect4Game.py

The code in maxconnect 4 was modified and AI implementation happens is Eval.py

Eval.py has Eval class that implements Minimax with alpha beta pruning.

The code in maxconnect4.py was filled in to the function interactive game mode and the functioning was extended into eval function.


For interactive mode, pass the following arguments:
		
python maxconnect4.py interactive [input_file] [computer-next/human-next] [depth]

	For one-move mode, pass the following arguments:
		
python maxconnect4.py one-move [input_file] [output_file] [depth]




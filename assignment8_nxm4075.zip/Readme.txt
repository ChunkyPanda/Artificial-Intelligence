Neil Malhotra

1001084075


I used puthon for this programming assignment. All the output is copied to a file "result.txt" as intructed. You can open results file by using nano or vim text editor in omega server.

For example:

nano result.txt



For running the program:


python compute_a_posteriori.py [observations]
for example, python compute_a_posteriori.py CLCCLLC
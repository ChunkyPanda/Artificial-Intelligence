Neil Malhotra

1001084075	

I have used JAVA language to implement the wumpus world problem. Using the files provided by professor Vamsikrishna. The file CheckTrueFalse consists of the modified code. The knowledge base for the wumpus world is contained in wumpus_rules.txt. The submission also includes additional_knowledge.txt.

The file CheckTrueFalse is modified by adding the functions ttEntails and Pl_true which implement the psuedocode for the following in the book, modified according to CheckTrueFalse. The program returns true or false if the statement holds in the knowledge base.



Intructions to run code on Omega:


to compile code:

javac CheckTrueFalse.java


to run code:

java CheckTrueFalse  wumpus_rules.txt additional_knowledge.txt statement.txt


